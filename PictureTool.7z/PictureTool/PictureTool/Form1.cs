﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Drawing2D;
using System.Text.RegularExpressions;
using System.Windows.Forms.DataVisualization.Charting;

namespace PictureTool
{
    public partial class Form1 : Form
    {
        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
        public Form1()
        {
            InitializeComponent();
            ///多个控件绑定鼠标拖拽事件
            textBox1.DragEnter += textBox_DragEnter;
            textBox2.DragEnter += textBox_DragEnter;
            textBox3.DragEnter += textBox_DragEnter;
            textBox4.DragEnter += textBox_DragEnter;

            ///多个控件绑定textbox显示路径事件
            textBox1.DragDrop += textBox_DragDrop;
            textBox2.DragDrop += textBox_DragDrop;
            textBox3.DragDrop += textBox_DragDrop;
            textBox4.DragDrop += textBox_DragDrop;
        }

        /// <summary>
        /// 自定义鼠标拖拽事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Link;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        /// <summary>
        /// 自定义textbox显示路径事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox_DragDrop(object sender, DragEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.Text = ((System.Array)e.Data.GetData(DataFormats.FileDrop)).GetValue(0).ToString();
        }

        /// <summary>
        /// 转换按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        string save_path; //图片保存路径
        //DL
        List<int> dl_sec_x = new List<int>();//DL收端x轴(秒数)
        List<int> dl_rate_rec_y = new List<int>();//DL收端y轴(收端速率)
        List<int> dl_rectime_x = new List<int>();//DL发端x轴
        List<int> dl_rate_send_y = new List<int>();//DL发端y轴(发端速率)
        //UL
        List<int> ul_sec_x = new List<int>();//UL收端x轴(秒数)
        List<int> ul_rate_rec_y = new List<int>();//UL收端y轴(收端速率)
        List<int> ul_rectime_x = new List<int>();//UL发端x轴
        List<int> ul_rate_send_y = new List<int>();//UL发端y轴(发端速率)
        bool UL_flag, DL_flag, UL_DL_Flag = false; 
        private void convert_Click(object sender, EventArgs e)
        {

            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            {
                //调用LOG处理方法
                DealLog(textBox1.Text, textBox2.Text, dl_sec_x, dl_rate_rec_y, dl_rectime_x, dl_rate_send_y);
                DealLog(textBox3.Text, textBox4.Text, ul_sec_x, ul_rate_rec_y, ul_rectime_x, ul_rate_send_y);
                //调用画图方法
                Drawing(this.chart1, dl_sec_x, dl_rate_rec_y, dl_rectime_x, dl_rate_send_y);
                Drawing(this.chart2, ul_sec_x, ul_rate_rec_y, ul_rectime_x, ul_rate_send_y);

                UL_DL_Flag = true;

            }//DL and UL 图片化
            else if (textBox1.Text != "" && textBox2.Text != "")
            {
                //调用LOG处理方法
                DealLog(textBox1.Text, textBox2.Text, dl_sec_x, dl_rate_rec_y, dl_rectime_x, dl_rate_send_y);
                //调用画图方法
                Drawing(this.chart1, dl_sec_x, dl_rate_rec_y, dl_rectime_x, dl_rate_send_y);

                DL_flag = true;

            }//DL图片化
            else if (textBox3.Text != "" && textBox4.Text != "")
            {
                //调用LOG处理方法
                DealLog(textBox3.Text, textBox4.Text, ul_sec_x, ul_rate_rec_y, ul_rectime_x, ul_rate_send_y);
                //调用画图方法
                Drawing(this.chart2, ul_sec_x, ul_rate_rec_y, ul_rectime_x, ul_rate_send_y);

                UL_flag = true;

            }//UL图片化
            else { MessageBox.Show("ログ格納先入力してください！");}
        }

        /// <summary>
        /// 日志处理方法过滤出X,Y轴的数据
        /// </summary>
        /// <param name="rec_path"></param>
        /// <param name="send_path"></param>
        private void DealLog(string rec_path, string send_path, List<int> sec_x, List<int> rate_rec_y, List<int> rectime_x, List<int> rate_send_y)
        {
            save_path = Path.GetDirectoryName(rec_path);//设置图片保存路径

            string[] read_recline = File.ReadAllLines(rec_path, Encoding.UTF8);//读取收端日志

            string[] read_sendline = File.ReadAllLines(send_path, Encoding.UTF8);//读取发端日志

            #region 正则表达式
            Regex reg_time = new Regex(@"[0-9]{1,}[.][0-9]*[-]\s*[0-9]{1,}[.][0-9]*|[0-9]{1,}[.][0-9]*[-][0-9]{1,}[.][0-9]*"); //匹配时间

            Regex reg_rate = new Regex(@"([0-9]{1,}[.][0-9]*|[0-9]{1,})\s*Gbits/sec|([0-9]{1,}[.][0-9]*|[0-9]{1,})\s*Mbits/sec|([0-9]{1,}[.][0-9]*|[0-9]{1,})\s*Kbits/sec|([0-9]{1,}[.][0-9]*|[0-9]{1,})\s*bits/sec"); //匹配速率
            #endregion

            #region 遍历收端日志
            for (int i = 0; i < read_recline.Length; i++)
            {
                Match match_time = reg_time.Match(read_recline[i]);
                if (match_time.Success)
                {
                    Match match_rate = reg_rate.Match(read_recline[i]);

                    if (match_rate.Success)
                    {
                        #region 收集X轴时间

                        string[] time = (string[])match_time.Value.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                        if (double.Parse(time[1]) - double.Parse(time[0]) <= 1)
                        {
                            sec_x.Add(Convert.ToInt32(Convert.ToDouble(time[0])));//x轴

                            #region 收集Y轴速率

                            string[] rate = (string[])match_rate.Value.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            if (rate[1].Contains("Gbits"))
                            {
                                rate_rec_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])) * 1000);
                            }
                            else if (rate[1].Contains("Mbits"))
                            {
                                rate_rec_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])));
                            }
                            else if (rate[1].Contains("Kbits"))
                            {
                                rate_rec_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])) / 1000);
                            }
                            else if (rate[1].Contains("bits"))
                            {
                                rate_rec_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])) / 1000000);
                            }

                            #endregion
                        }

                        #endregion
                    }
                }
            }
            #endregion

            #region 遍历发端日志
            for (int i = 0; i < read_sendline.Length; i++)
            {
                Match match_time = reg_time.Match(read_sendline[i]);
                if (match_time.Success)
                {
                    Match match_rate = reg_rate.Match(read_sendline[i]);

                    if (match_rate.Success)
                    {
                        #region 收集X轴时间

                        string[] time = (string[])match_time.Value.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                        if (double.Parse(time[1]) - double.Parse(time[0]) <= 1)
                        {
                            rectime_x.Add(Convert.ToInt32(Convert.ToDouble(time[0])));//x轴

                            #region 收集Y轴速率

                            string[] rate = (string[])match_rate.Value.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            if (rate[1].Contains("Gbits"))
                            {
                                rate_send_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])) * 1000);
                            }
                            else if (rate[1].Contains("Mbits"))
                            {
                                rate_send_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])));
                            }
                            else if (rate[1].Contains("Kbits"))
                            {
                                rate_send_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])) / 1000);
                            }
                            else if (rate[1].Contains("bits"))
                            {
                                rate_send_y.Add(Convert.ToInt32(Convert.ToDouble(rate[0])) / 1000000);
                            }

                            #endregion
                        }

                        #endregion
                    }
                }
            }
            #endregion
        }


        /// <summary>
        /// 画图方法
        /// </summary>
        private void Drawing(Chart chart,List<int> sec_X, List<int> rate_rec_Y, List<int> rectime_X,List<int> rate_send_Y) 
        {
            chart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;//去X轴网格线
            chart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;//去y轴网格线
            chart.ChartAreas[0].AxisX.LineWidth = 2;//X轴粗细
            chart.ChartAreas[0].AxisY.LineWidth = 2;//Y轴粗细
            chart.Series[0].BorderWidth = 4;//折线1粗细
            chart.Series[1].BorderWidth = 2;//折线2粗细
            chart.Series[0].Color = Color.Blue;
            chart.Series[1].Color = Color.Red;

            try
            {
                chart.ChartAreas[0].AxisY.Maximum = rate_send_Y.Max() + 100;//设置Y轴最大值
                chart.ChartAreas[0].AxisY.Minimum = 0;//设置Y轴最小值
                chart.ChartAreas[0].AxisY.Interval = rate_send_Y.Max() / 12;//设置每个刻度的跨度

                chart.Series[1].Points.DataBindXY(sec_X, rate_rec_Y);//receive端折线
                chart.Series[0].Points.DataBindXY(rectime_X, rate_send_Y);//send端折线
            }
            catch (Exception)
            {
                MessageBox.Show("正しいIperfログ読み込んでください！");
            }
        }

        /// <summary>
        /// 保存图片方法
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="chart"></param>
        public void ExportChart(string SavePth , string fileName , Chart chart)
        {
            string fullFileName = save_path + "\\" + fileName + ".png";
            chart.Size = new Size(1920,1080);//设置图片保存分辨率
            chart.SaveImage(fullFileName,ChartImageFormat.Png); //保存图片
        }

        /// <summary>
        /// 保存按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void save_Click(object sender, EventArgs e)
        {

            if (UL_DL_Flag)
            {
                string fileName_dl = "DL_Throughput";
                string fileName_ul = "UL_Throughput";
                ExportChart(save_path, fileName_dl,this.chart1);
                ExportChart(save_path, fileName_ul, this.chart2);
                MessageBox.Show("保存OK","^_^");

            }//DL and UL 图片保存
            else if (DL_flag)
            {
                string fileName_dl = "DL_Throughput";
                ExportChart(save_path, fileName_dl, this.chart1);
                MessageBox.Show("保存OKです！","^_^");

            }//DL图片保存
            else if (UL_flag)
            {
                string fileName_ul = "UL_Throughput";
                ExportChart(save_path, fileName_ul, this.chart2);
                MessageBox.Show("保存OK","^_^");

            }//UL图片保存

            chart1.Size = new Size(this.tabControl1.Width, this.tabControl1.Height - 30);
            chart2.Size = new Size(this.tabControl1.Width, this.tabControl1.Height - 30);
        }

        /// <summary>
        /// 清除键
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Clear_Click(object sender, EventArgs e)
        {
            this.chart1.Series[1].Points.Clear();//清空DL折线
            this.chart1.Series[0].Points.Clear();//清空DL折线
            this.chart2.Series[1].Points.Clear();//清空UL折线
            this.chart2.Series[0].Points.Clear();//清空UL折线

            dl_sec_x.Clear();//清空DL收端x轴(秒数)
            dl_rate_rec_y.Clear();//清空DL收端y轴(收端速率)
            dl_rectime_x.Clear();//清空DL发端x轴
            dl_rate_send_y.Clear();//清空DL发端y轴(发端速率)
                                                       
            //UL
            ul_sec_x.Clear();//清空UL收端x轴(秒数)
            ul_rate_rec_y.Clear();//清空UL收端y轴(收端速率)
            ul_rectime_x.Clear();//清空UL发端x轴
            ul_rate_send_y.Clear();//清空UL发端y轴(发端速率)
            UL_flag = false;
            DL_flag = false;
            UL_DL_Flag = false;

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

            chart1.Size = new Size(this.tabControl1.Width,this.tabControl1.Height-30);
            chart2.Size = new Size(this.tabControl1.Width, this.tabControl1.Height-30);
        }
    }
}
